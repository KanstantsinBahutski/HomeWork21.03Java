import javax.swing.*;
import java.util.Arrays;

public class Main {
    public static void main(String[] args) {
        str("Любовь", "Смерть", "Java", "|"); //Проект1
        System.out.println(str("Любовь", "Смерть", "Java", "|")); //Проект1
        String text = "I spent way more time than I expected";
        homework(text);

    }

    public static String str(String x1, String x2, String x3, String y) { //Проект1
        return x1 + y + x2 + y + x3; //Проект1
    }
    public static void homework(String text){
        System.out.println(text.charAt(0));
    }

}